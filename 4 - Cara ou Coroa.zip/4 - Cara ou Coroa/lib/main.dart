import 'package:flutter/material.dart';
import 'package:cara_ou_coroa/Jogar.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Jogar(),
  ));
}
