import 'package:flutter/material.dart';
import 'package:alcool_gasolina/Home.dart';

void main() {
  runApp(MaterialApp(
    home: Home(),
    debugShowCheckedModeBanner: false,
  ));
}
