import 'package:flutter/material.dart';
import 'package:preco_bitcoin/Home.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Home(),
  ));
}
